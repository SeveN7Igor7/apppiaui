// src/services/googleapikey.ts

// Aqui você pode importar a variável de ambiente ou definir diretamente (não recomendado para produção)
export const GOOGLE_API_KEY = 'AIzaSyBB9IoVdFTIGxCmCZzKLrMtPOvGmarMzkg';
